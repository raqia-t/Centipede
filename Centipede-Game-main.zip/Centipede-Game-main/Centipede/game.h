#pragma once

void positionfactory(int &randx, int &randy, int i, std::vector<mushroom> &randset);
