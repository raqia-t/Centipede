# Centipede-Game
A linux based shooting game made using graphics.h and utils.h in C++
Run the make file by 'make' and execute the game application using command './game'
